cd src
make clean
make all
