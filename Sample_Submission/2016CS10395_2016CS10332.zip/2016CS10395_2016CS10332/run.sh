#!/bin/sh
./src/main $1 $2
